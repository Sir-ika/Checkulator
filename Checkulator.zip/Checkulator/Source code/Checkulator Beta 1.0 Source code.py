def mathscheck(input = None, awnser = None):
#Defining the mathscheck function with default None values, followed by the function body
    if input == None:
        print("!NO INPUT!")
    elif input == awnser:
        print("Correct! :)")
    else: print("Incorrect! :(")
    inputmath()
#If else block checking if input is equal to awnser, if it is it prints correct, if not it prints incorrect
def inputmath():
    num1 = input("Please enter the problem: ")
    if num1 == "Exit":
        maths()
    num2 = input("Please enter your solution to have it verified: ")
    #Creates and assigns the values of the num1 and num2 variables
    evalednum1 = eval(num1)
    intnum2 = int(num2)
    #Converts and evaluates the input
    print("                         ")
    print("                         ")
    #Blank print statements for easy to read spacing in output
    mathscheck(evalednum1, intnum2)
    #Calls mathscheck function with num1 and num2 variables
    print("                         ")
    print("                         ")
    print("                         ")
    #Blank print statements for easy to read spacing in output
    print("==========Note! This app uses python, so for addition please use + , for subtraction please use - , for division please use / , for parenthasies please use () , for multiplication please use * , for exponents please use ** . examples: 5 + 5 (addition) 5 - 5 (subtraction) (5 + 5) (parenthasies) 5 * 5 (multiplication) 5 / 5 (division) 5 ** 5 (exponents)========== ")
    #Note to tell users how to properly format math in python






print("==========NOTE==========")
print("This is a basic calculator, and therefore can only do things such as: Addition, Subtraction, Multiplication, Division, Parenthasies, Exponents.")
print("==========END NOTE==========")
print("To enter the math checker, please type Checker in the [Type your maths, then press [ENTER]] section. To exit the checker, please type Exit in the [Please enter the problem: ] section.        ")
print("         ")
print("         ")
def maths():
    inputs = input("Type your maths, then press [ENTER]")
    if inputs == "Checker":
        inputmath()
    result = eval(inputs)
    print(f"Your result is: {result} ! :)")
    maths()
print("==========Note! This app uses python, so for addition please use + , for subtraction please use - , for division please use / , for parenthasies please use () , for multiplication please use * , for exponents please use ** . examples: 5 + 5 (addition) 5 - 5 (subtraction) (5 + 5) (parenthasies) 5 * 5 (multiplication) 5 / 5 (division) 5 ** 5 (exponents)========== ")
print("         ")
print("         ")
print("         ")
maths()